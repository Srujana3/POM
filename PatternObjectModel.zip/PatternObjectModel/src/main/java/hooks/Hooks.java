package hooks;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import wdMethods.ProjectMethods;
import wdMethods.SeMethods;

public class Hooks extends SeMethods {

	@Before
	public void setData(Scenario sc) {
		testCaseName="TC001_LoginAndLogout";
		testDescription=sc.getName();
		System.out.println(sc.getName());
		testNodes="Leads";
		category="Smoke";
		authors="srujana";
		startResult();
		startTestModule(testCaseName, testDescription);	

		test = startTestCase(testNodes);
		test.assignCategory(category);
		test.assignAuthor(authors);
		startApp("chrome");
		
		
}
	
	@After
	public void closeBrowser()
	{
		endResult();

		closeAllBrowsers();
	}
}