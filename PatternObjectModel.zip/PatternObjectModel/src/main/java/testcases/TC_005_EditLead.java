package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC_005_EditLead extends ProjectMethods  {
	
	@BeforeTest
	public void setData()
	{
		testCaseName="TC005_EditLead";
		testDescription="Editing the lead info";
		testNodes="Leads";
		category="Functional";
		authors="srujana";
		browserName="chrome";
		dataSheetName="TC005";

	}
	@Test(dataProvider="fetchData")

	public void editLead(String username,String password,String FirstName,String title,String companyName)
	{
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogIn()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLead()
		.enterFirstname(FirstName)
		.clickFindLeads()
		.clickFirstlead()
		.clickEdit()
		.verifyPageTitle(title)
		.clearCompanyName()
		.typeCompanyName(companyName)
		.clickUpdate()
		.verifyCompany(companyName);
	}

}