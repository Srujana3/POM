 package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC_007_DeleteLead extends ProjectMethods {
	
	@BeforeTest
	public void setData()
	{
		testCaseName="TC007_DeleteLead";
		testDescription="Deleting Lead Id";
		testNodes="Leads";
		category="Functional";
		authors="srujana";
		browserName="chrome";
		dataSheetName="TC007";

	}
	@Test(dataProvider="fetchData")
	
	public void deleteLead(String username,String password,String phonenum)
	{
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogIn()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLead()
		.clickPhoneNum()
		.clearPhoneNum()
		.typePhoneNum(phonenum)
		.clickFindLeads()
		.getFirstLead()
		.clickFirstlead()
		.clickDelete()
		.clickFindLead()
		.enterLeadId()
		.clickFindLeads()
		.verifyErrMsg();
		
	}
	

}