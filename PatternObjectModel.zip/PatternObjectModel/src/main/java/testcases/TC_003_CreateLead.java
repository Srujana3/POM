package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC_003_CreateLead extends ProjectMethods{
	@BeforeTest
	public void setData()
	{
		testCaseName="TC003_CreateLead";
		testDescription="create the Lead";
		testNodes="Leads";
		category="Functional";
		authors="srujana";
		browserName="chrome";
		dataSheetName="TC003";
	}
	@Test(dataProvider="fetchData",invocationCount=2,threadPoolSize=2)
	public void CreateLeadTestCase(String username,String password,String companyName,String Firstname,String lastname,String verifyName)
	{
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogIn()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.typeCompany(companyName)
		.typeFirstName(Firstname)
		.typeLastName(lastname)
		.clickCreateLead()
		.verifyFirstName(verifyName);
	}

}