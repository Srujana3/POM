package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC_004_MergeLead extends ProjectMethods{
	@BeforeTest
	public void setData()
	{
		testCaseName="TC004_MergeLeads";
		testDescription="Merging two Lead Id's";
		testNodes="Leads";
		category="Functional";
		authors="srujana";
		browserName="chrome";
		dataSheetName="TC004";

	}
	@Test(dataProvider="fetchData")
	public void MergeLeads(String username,String Password,String LeadId1,String LeadId2)
	{
		
		new LoginPage()
		.enterUserName(username)
		.enterPassword(Password)
		.clickLogIn()
		.clickCRMSFA()
		.clickLeads()
		.clickMergeLead()
		.clickFirstIcon()
		.switchWindow1()
		.enterLeadid1(LeadId1)
		.clickFindLead()
		.geteleText()
		.clickFisrtCell()
		.switchWindow()
		.clickSecondIcon()
		.switchWindow1()
		.enterLeadid1(LeadId2)
		.clickFindLead()
		.clickFisrtCell()
		.switchWindow()
		.clickMerge()
		.alertAccept()
		.clickfindLeads()
		.enterLeadId()
		.clickFindLeads()
		.verifyErrMsg();
		
	}
}