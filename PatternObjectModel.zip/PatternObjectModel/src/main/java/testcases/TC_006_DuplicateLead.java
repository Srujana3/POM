package testcases;

import org.testng.annotations.*;


import pages.FindLeads;
import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC_006_DuplicateLead extends ProjectMethods{
	
	@BeforeTest
	public void setData()
	{
		testCaseName="TC006_DuplicateLeads";
		testDescription="Duplicate Lead";
		testNodes="Leads";
		category="Functional";
		authors="srujana";
		browserName="chrome";
		dataSheetName="TC006";

	}
	@Test(dataProvider="fetchData")
	public void DuplicateLead(String userName,String password,String email,String sectionHeader) {
		
		String firstName = new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLogIn()
		.clickCRMSFA()
		.clickLeads()
		.clickFindLead()
		.clickEmail()
		.typeEmail(email)
		.clickFindLeads()
		.getFirstName();
		
		new FindLeads()
		.clickFirstName()
		.clickDuplicate()
		.verifySectionHeader(sectionHeader)
		.clickCreateLead()
		.verifyFirstNameDup(firstName);
		
	}
}