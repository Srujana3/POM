package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class FindLeads extends ProjectMethods
{

	public FindLeads()
	{
		PageFactory.initElements(driver, this);
	}
	@FindBy(how=How.XPATH,using="//span[@class='x-tab-strip-inner']/span[text()='Email']")
	private WebElement eleEmail;
	
	public FindLeads clickEmail()
	{
		click(eleEmail);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[@class='x-tab-strip-inner']/span)[2]")
	private WebElement elePhoneNum;
	
	public FindLeads clickPhoneNum()
	{
		click(elePhoneNum);
		return this;
	}

	@FindBy(how=How.NAME,using="phoneCountryCode")
	private WebElement elePhoneNumClear;
	
	public FindLeads clearPhoneNum()
	{
		elePhoneNumClear.clear();;
		return this;
	}
	
	@FindBy(how=How.NAME,using="phoneNumber")
	private WebElement eleEnterPhoneNumber;
	
	public FindLeads typePhoneNum(String num)
	{
		type(eleEnterPhoneNumber,num);
		return this;
	}
	@FindBy(how=How.XPATH,using="(//div[@class='x-form-item x-tab-item']//following::input)[5]")
	private WebElement eleTypeEmail;
	
	public FindLeads typeEmail(String emailId)
	{
		type(eleTypeEmail,emailId);
		return this;
	}
	@FindBy(how=How.XPATH,using="//label[text()='Lead ID:']/following::input[1]")
	private WebElement eleTypeLeadId;
	
	public FindLeads enterLeadId()
	{
		
		System.out.println(firstLeadId);
		type(eleTypeLeadId,firstLeadId);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//label[text()='Lead ID:']/following::input[2]")
	private WebElement eleTypeFirstName;
	
	public FindLeads enterFirstname(String name)
	{
		
		type(eleTypeFirstName,name);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Find Leads']")
	private WebElement eleFindLeads;
	
	public FindLeads clickFindLeads()
	{
		click(eleFindLeads);
		return this;
	}
	@FindBy(how=How.XPATH,using="(//div[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]/a")
	private WebElement eleFirstName;
	
	public ViewLead clickFirstName()
	{
		click(eleFirstName);
		return new ViewLead();
	}
	public String getFirstName()
	{
		return eleFirstName.getText();
		
	}
	
	@FindBy(how=How.XPATH,using="(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a")
	private WebElement eleFirstLead;
	
	public ViewLead clickFirstlead()
	{
		click(eleFirstLead);
		return new ViewLead();
	}

	public FindLeads getFirstLead()
	{
		firstLeadId= eleFirstLead.getText();
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[text()='No records to display']")
	private WebElement eleErrMsg;
	
	public FindLeads verifyErrMsg()
	{
		getText(eleErrMsg);
		return this;
	}

}