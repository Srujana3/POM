package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class MergeLead extends ProjectMethods {
	
	public MergeLead()
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.XPATH,using="(//img[@alt='Lookup'])[1]")
	private WebElement eleLookup1;
	
	public MergeLead clickFirstIcon()
	{
		click(eleLookup1);
		return this;
	}
	public FindLeadsWindow switchWindow1() {
		switchToWindow(1);
		return new FindLeadsWindow();
	}
	
	@FindBy(how=How.XPATH,using="(//img[@alt='Lookup'])[2]")
	private WebElement eleLookup2;
	
	public MergeLead clickSecondIcon()
	{
		click(eleLookup2);
		return this;
	}
	
	@FindBy(how=How.LINK_TEXT,using="Merge")
	private WebElement eleMerge;
	
	public MergeLead clickMerge()
	{
		clickWithNoSnap(eleMerge);
		return this;
	}
	public ViewLead alertAccept()
	{
		acceptAlert();
		return new ViewLead();
	}
	
}