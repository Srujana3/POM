package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class OpenTaps extends ProjectMethods {
	
	public OpenTaps()
	{
		PageFactory.initElements(driver, this);
	}
	
	public OpenTaps verifyPageTitle(String title) {
		System.out.println(title);
		boolean verifyTitle = verifyTitle(title);
		return this;
	}
	@FindBy(how=How.ID,using="updateLeadForm_companyName")
	private WebElement eleCompanyName;
	public OpenTaps clearCompanyName()
	{
		eleCompanyName.clear();
		return this;
	}
	
	public OpenTaps typeCompanyName(String companyName)
	{
		type(eleCompanyName,companyName);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@value='Update']")
	private WebElement eleUpdate;
	public ViewLead clickUpdate()
	{
		click(eleUpdate);
		return new ViewLead();
	}

}