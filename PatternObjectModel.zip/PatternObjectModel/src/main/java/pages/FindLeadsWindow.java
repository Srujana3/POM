package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;
	
public class FindLeadsWindow extends ProjectMethods {
	public FindLeadsWindow()
	{
		PageFactory.initElements(driver, this);
	}
	@FindBy(how=How.XPATH,using="(//div[@class='x-form-element']/input)[1]")
	private WebElement eleLeadId;
	public FindLeadsWindow enterLeadid1(String leadId)
	{
		type(eleLeadId,leadId);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Find Leads']")
	private WebElement eleFindLead;
	 public FindLeadsWindow clickFindLead()
	{
		click(eleFindLead);
		return this;
	}
	
	 @FindBy(how=How.XPATH,using="(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]")
		private WebElement eleFirstCellgetText;
	 public FindLeadsWindow geteleText()
	 {
		 firstLeadId= getText(eleFirstCellgetText);
		 System.out.println(firstLeadId);
		return this;
	 }
	@FindBy(how=How.XPATH,using="(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]")
	private WebElement eleFirstCell;
	public FindLeadsWindow clickFisrtCell()
	{
		clickWithNoSnap(eleFirstCell);
		return this;
	}
	
	
	
	public MergeLead switchWindow()
	{
		switchToWindow(0);
		return new MergeLead();
	}
	
	
	

	

}