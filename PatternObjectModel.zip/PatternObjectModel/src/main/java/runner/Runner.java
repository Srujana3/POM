package runner;

import org.junit.runner.RunWith;
import cucumber.api.junit.*;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="./src/main/java/features/Login.feature",glue= {"pages","hooks"},tags= {"@Smoke,@Sanity"},monochrome=true)
public class Runner {

}